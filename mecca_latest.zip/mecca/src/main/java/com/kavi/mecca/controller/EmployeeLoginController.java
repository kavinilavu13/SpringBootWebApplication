package com.kavi.mecca.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.kavi.mecca.request.EmployeeLogin;
import com.kavim.mecca.service.EmployeeService;

@RestController
public class EmployeeLoginController {
  
  @Autowired
  EmployeeService employeeService;
 
  @PostMapping("/EmployeeLogin")
  public String login(@RequestBody EmployeeLogin empdata)
  {
	  System.out.println("Employee Login request");
	return employeeService.validateEmployee(empdata);
	  
  }


}
