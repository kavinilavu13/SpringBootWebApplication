package com.kavi.mecca.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Amenities {
	
    private int amenitiesId;
    private String amenitiesTypes;  
      private List<SubAmenitiesType> subAmenitiesType;
 @OneToMany( targetEntity=SubAmenitiesType.class,mappedBy="amenities",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	public List<SubAmenitiesType> getSubAmenitiesType() {
		return subAmenitiesType;
	}
	public void setSubAmenitiesType(List<SubAmenitiesType> subAmenitiesType) {
		this.subAmenitiesType = subAmenitiesType;
	}
	@Id
    @GeneratedValue
	public int getAmenitiesId() {
		return amenitiesId;
	}
	public void setAmenitiesId(int amenitiesId) {
		this.amenitiesId = amenitiesId;
	}
	public String getAmenitiesTypes() {
		return amenitiesTypes;
	}
	public void setAmenitiesTypes(String amenitiesTypes) {
		this.amenitiesTypes = amenitiesTypes;
	}
	
}
