package com.kavi.mecca.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import javax.servlet.annotation.MultipartConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.kavi.mecca.entity.Profile;
import com.kavi.mecca.repository.ProfileRepository;
import com.kavi.mecca.request.ProfileRequest;
//@MultipartConfig(maxFileSize = 10737418240L, maxRequestSize = 10737418240L, fileSizeThreshold = 52428800)
@RestController
public class MeccaProfileController {
	@Autowired
	ProfileRepository profileRepository;

/*	@PostMapping("/profile")
	public String createProfile(@RequestBody Profile profile) {
		String name = profile.getName();

		String photo = "IMG-20180604-WA0009.jpg";
		profile.setPhoto(photo);
		String getphoto = profile.getPhoto();
		System.err.println(getphoto);
		Profile savedprofile = profileRepository.save(profile);

		return "AddUser";
	}*/
	@RequestMapping(value = "/AddUser", method = RequestMethod.POST)
	 public String  multiUploadFileModel(@ModelAttribute ProfileRequest model) {
	        try {
	        	
	           String  image= saveUploadedFile(model.getImage());
	           String proof1= saveUploadedFile(model.getProof1());
	           String proof2= saveUploadedFile(model.getProof2());
	          Profile profile=new Profile();
	      
	           profile.setName(model.getName());
	          profile.setDate_of_birth(model.getDate_of_birth());
	          profile.setPhone_number(model.getPhone_number());
	          profile.setRole(model.getRole());
	          profile.setGender(model.getGender());
		       
	          profile.setStreet(model.getStreet());
	          profile.setState(model.getState());
	          profile.setCity(model.getCity());
	          profile.setArea(model.getArea());
	          profile.setCountry(model.getCountry());
	          profile.setDistrict(model.getDistrict());
			  profile.setZip_code(model.getZip_code());  
	          
	          profile.setEmail_id(model.getEmail_id());	        
	          profile.setFacebook_id(model.getFacebook_id());
	          profile.setInstragram_id(model.getInstragram_id());
              profile.setWhats_app_number(model.getWhats_app_number());

	          
	         profile.setAadhar_card(proof1);
	         profile.setPan_card(proof2);
	          
	          
	          profile.setPhoto(image);	       
	          Profile savedprofile = profileRepository.save(profile);

	            
	         // Profile saved = profileRepository.save(model);

		        
	          //formRepo.save(model.getName(),model.getEmail_id()); //Save as you want as per requirement 
	        } catch (IOException e) {
	          //  return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	        }
	        //return new ResponseEntity("Successfully uploaded!", HttpStatus.OK);
	    
	return "redirect:/ViewUser.html";
	}
	 
	 private String saveUploadedFile(MultipartFile file) throws IOException {
		 String image_path="";
			 if (!file.isEmpty()) {
	            byte[] bytes = file.getBytes();
	          Path   path = Paths.get("E:\\xampp\\htdocs\\mecca\\" + file.getOriginalFilename());
	           image_path=path.toString(); 
	            System.out.println(path);
	            Files.write(path, bytes);
	        }
			return image_path;
	    }
	
	
	// 3.1.3 maps html form to a Model
/*	@RequestMapping(value = "/AddUser", method = RequestMethod.POST)
	public ResponseEntity<?> multiUploadFileModel(@ModelAttribute ProfileRequest model) {

		
		try {

			saveUploadedFiles(Arrays.asList(model.getImage()));

		} catch (IOException e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity("Successfully uploaded!", HttpStatus.OK);

	}

	private void saveUploadedFiles(List<MultipartFile> files) throws IOException {

		
		System.err.println("files:-"+files);
		for (MultipartFile file : files) {

			if (file.isEmpty()) {

				System.err.println("inside if:-"+file);

				continue; // next pls
			}

			byte[] bytes = file.getBytes();
			Path path = Paths.get(file.getOriginalFilename());

			System.err.println("path :-"+path);
			Files.write(path, bytes);

		}
	}*/

	@GetMapping("/profile")
	List<Profile> retrieveProfile() {
		
		List<Profile> profile = profileRepository.findAll();
		System.out.println(profile);
		return profile;
	}

	@GetMapping("/profile/{id}")
	Profile findById(@PathVariable("id") Long id) {
		// TODO Auto-generated method stub
		System.out.println(id);
		Optional<Profile> profile = profileRepository.findById(id);
		return profile.get();
	} 


	@RequestMapping(value = "/UpdateUser", method = RequestMethod.POST)
public	String updateProfile(@ModelAttribute ProfileRequest model) throws IOException {
		// TODO Auto-generated method stub
		
		 
		String	image = saveUploadedFile(model.getImage());		
         String proof1= saveUploadedFile(model.getProof1());
         String proof2= saveUploadedFile(model.getProof2());
       Profile profile=new Profile();
    
         profile.setName(model.getName());
        profile.setDate_of_birth(model.getDate_of_birth());
        profile.setPhone_number(model.getPhone_number());
        profile.setRole(model.getRole());
        profile.setGender(model.getGender());
	       
        profile.setStreet(model.getStreet());
        profile.setState(model.getState());
        profile.setCity(model.getCity());
        profile.setArea(model.getArea());
        profile.setCountry(model.getCountry());
        profile.setDistrict(model.getDistrict());
		  profile.setZip_code(model.getZip_code());  
        
        profile.setEmail_id(model.getEmail_id());	        
        profile.setFacebook_id(model.getFacebook_id());
        profile.setInstragram_id(model.getInstragram_id());
        profile.setWhats_app_number(model.getWhats_app_number());

        
       profile.setAadhar_card(proof1);
       profile.setPan_card(proof2);
        
        
        profile.setPhoto(image);	       
        Profile savedprofile = profileRepository.save(profile);
		String response="";
    	System.err.println(savedprofile);
		if (savedprofile != null) {
			response = "updated Sucessfully";
		} else {
			response = "updated Failure";
		}
	
		return response;
	}
	/*@PutMapping("/profile")
	Profile updateProfile(@RequestBody Profile profile) {
		// TODO Auto-generated method stub
		Profile update_profile = profileRepository.save(profile);
		return update_profile;
	}*/

	@DeleteMapping("/profile/{id}")
	String deleteProfile(@PathVariable("id") Long id) {
		// TODO Auto-generated method stub
		profileRepository.deleteById(id);
		return "deleted successfully";
	}

	// Get the form field vaues which are populated using the backing bean and
	// store it in db
/*	@RequestMapping(value = "/AddUser", method = RequestMethod.POST)
	public String processRequest(@ModelAttribute("adduser") Profile profile) {
		String response = "";
		System.err.println(profile.getName());
		Profile savedprofile = profileRepository.save(profile);

		System.err.println(savedprofile);
		if (savedprofile != null) {
			response = "adduser-0";
		} else {
			response = "adduser-1";
		}
		return "AddUser.html";
	}*/
}
