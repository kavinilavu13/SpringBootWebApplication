package com.kavi.mecca.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kavi.mecca.entity.Amenities;

@Repository
public interface AmenitiesTypeRepository extends JpaRepository<Amenities, Long>{ 
	
}
