package com.kavi.mecca.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kavi.mecca.entity.Amenities;
//import com.kavi.mecca.entity.AmenitiesType;
import com.kavi.mecca.entity.Profile;
import com.kavi.mecca.entity.SubAmenitiesType;
//import com.kavi.mecca.entity.SubAmenities;
import com.kavi.mecca.repository.AmenitiesTypeRepository;
import com.kavi.mecca.repository.SubAmenitiesRepository;
import com.kavi.mecca.request.AmenitiesRequest;

@RestController
public class MeccaAmenitiesController {
	@Autowired
	AmenitiesTypeRepository amenitiesTypeRepository;
	@Autowired
	SubAmenitiesRepository subAmenitiesRepository;
	
	@PostMapping("/amenities")
	public String amenitiesType() 
	{
		SubAmenitiesType subame1=new SubAmenitiesType();
		subame1.setSubAmenitiesName("Tea");
		
		SubAmenitiesType subame2=new SubAmenitiesType();
		subame2.setSubAmenitiesName("Tea");    
		
		
		Amenities amen=new Amenities();
		amen.setAmenitiesTypes("Breakfast");
		
		
		 amenitiesTypeRepository.save(amen);
		 subAmenitiesRepository.save(subame1);
		 subAmenitiesRepository.save(subame2);
		return "Date added Sucessfully";
	}	
	@GetMapping("/amenities")
	List<Amenities> retrieveAmenities() 
	{
		List<Amenities> amenities = amenitiesTypeRepository.findAll();
		System.out.println(amenities);
		return amenities;
	}
	
	/*@GetMapping("/amenities/{id}")
	Amenities findById(@PathVariable("id") String id) {
		// TODO Auto-generated method stub
		System.err.println("value:-"+id);
		Amenities profileData = null;
		profileData=	amenitiesTypeRepository.findSubservice(id);

		//Optional<SubAmenities> subAmenities = subAmenitiesRepository.findById(id);
		//return subAmenities.get();
		return null;
	} */
/*	@PostMapping("/amenities")
	public String amenitiesType(@RequestBody AmenitiesRequest amenitiesRequest) 
	{
		AmenitiesType amenitiesType = new AmenitiesType();
		amenitiesType.setService_type_name(amenitiesRequest.getService_name());
		amenitiesType = amenitiesTypeRepository.save(amenitiesType);
		int amenitiesId = amenitiesType.getService_type_id();
		List<String> subTypeList = amenitiesRequest.getService_type_name();
		for (String subAmeniteName : subTypeList) 
		{
			SubAmenities subAmenities = new SubAmenities();
			//subAmenities.setService_type_id(amenitiesId);
			subAmenities.setService_name(subAmeniteName);
			subAmenitiesRepository.save(subAmenities);
		}
		return "Date added Sucessfully";
	}	
	@GetMapping("/amenities")
	List<AmenitiesType> retrieveAmenities() 
	{
		List<AmenitiesType> amenities = amenitiesTypeRepository.findAll();
		System.out.println(amenities);
		return amenities;
	}
	*/
	/*@GetMapping("/amenities/{id}")
	SubAmenities findById(@PathVariable("id") String id) {
		// TODO Auto-generated method stub
		System.err.println("value:-"+id);
		SubAmenities profileData = null;
		profileData=	subAmenitiesRepository.findSubservice(id);

		//Optional<SubAmenities> subAmenities = subAmenitiesRepository.findById(id);
		//return subAmenities.get();
		return null;
	} */
	
}
