package com.kavi.mecca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


import com.kavi.mecca.repository.AmenitiesTypeRepository;

@RestController
public class AddBuildingController {
	/*@Autowired

	AmenitiesTypeRepository amenitiesTypeRepository;

	@GetMapping("/amenities")
	List<AmenitiesType> retrieveProfile() {
		List<AmenitiesType>  amenities = amenitiesTypeRepository.findAll();
		System.out.println( amenities);
		return  amenities;
	}*/

}
