package com.kavi.mecca.entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class SubAmenitiesType {

	private int subAmenitiesId;
	private String subAmenitiesName;
	private Amenities amenities;	
	@ManyToOne
	@JoinColumn(name="amenitiesId")
	public Amenities getAmenities() {
		return amenities;
	}
	public void setAmenities(Amenities amenities) {
		this.amenities = amenities;
	}


	public String getSubAmenitiesName() {
		return subAmenitiesName;
	}
	
	@Id
	@GeneratedValue
	public int getSubAmenitiesId() {
		return subAmenitiesId;
	}
	public void setSubAmenitiesId(int subAmenitiesId) {
		this.subAmenitiesId = subAmenitiesId;
	}
	public void setSubAmenitiesName(String subAmenitiesName) {
		this.subAmenitiesName = subAmenitiesName;
	}
}
