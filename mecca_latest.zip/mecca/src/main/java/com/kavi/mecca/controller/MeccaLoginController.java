package com.kavi.mecca.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kavi.mecca.entity.Profile;
import com.kavi.mecca.repository.ProfileRepository;
import com.kavi.mecca.request.LoginRequest;
import com.kavim.mecca.service.LoginService;

@RestController
public class MeccaLoginController {
	@Autowired
	LoginService loginService;
	
@PostMapping("/login")
	String loginChecking(@RequestBody LoginRequest login) {
	return loginService.loginChecker(login); 

}
}
