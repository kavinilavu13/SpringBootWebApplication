/*package com.kavi.mecca.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="servicetype")
public class AmenitiesType {
	@Id
	@GeneratedValue
	private int service_type_id;
	private String service_type_name;	
	private List<SubAmenities> subAmenities;
	
//	@OneToMany(targetEntity=SubAmenities.class,mappedBy="amenType",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	public List<SubAmenities> getSubAmenities() {
		return subAmenities;
	}
	public void setSubAmenities(List<SubAmenities> subAmenities) {
		this.subAmenities = subAmenities;
	}
	public int getService_type_id() {
		return service_type_id;
	}
	public void setService_type_id(int service_type_id) {
		this.service_type_id = service_type_id;
	}
	public String getService_type_name() {
		return service_type_name;
	}
	public void setService_type_name(String service_type_name) {
		this.service_type_name = service_type_name;
	}
	

}
*/