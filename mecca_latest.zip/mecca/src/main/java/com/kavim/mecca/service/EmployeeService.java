package com.kavim.mecca.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.kavi.mecca.repository.EmployeeRepository;
import com.kavi.mecca.request.EmployeeLogin;
@Service("EmployeeLoginController")
public class EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;
	public String validateEmployee(EmployeeLogin empdata)
	{
		String Password=empdata.getPassword();
		String phonenumber=empdata.getPhonenumber();
		String Response="";
		if(Password.equals("kavi") && phonenumber.equals("9600797405"))
		{
			Response="Validate User";
			System.out.println(Response);
		}
		else
		{
			Response="Validate User";

			System.out.println(Response);
		}
		return Response;
		
	}

}
