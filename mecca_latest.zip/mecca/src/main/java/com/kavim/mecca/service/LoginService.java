package com.kavim.mecca.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kavi.mecca.entity.Profile;
import com.kavi.mecca.repository.ProfileRepository;
import com.kavi.mecca.request.LoginRequest;

@Service("MeccaLoginController")
public class LoginService {
	@Autowired
	ProfileRepository profileRepository;
	
	public String loginChecker(LoginRequest reqData)
	{

		String response = "";
		String phonenumber = reqData.getPhone_number();
		String password = reqData.getPassword();
		Profile profileData = null;
		profileData=	profileRepository.findProfileByPhoneNumber(phonenumber, password);
		System.err.println(profileData);
		if (profileData != null) {
			response = "Login Success";
		} else {
			response = "Login Failure";
		}
		return response;
	}

}
