$('#updateuser').on('submit', function(e) {	
	alert("uodate user");
	e.preventDefault();
	if ($.trim($("#userid").val()) === ""|| $.trim($("#ownerName").val()) === "") {
		/*	$('#sticky').empty();*/
			toastr.info('Please fill out the field');
				$('.loader').hide()
	}
	else
		{
	var userid = 	$.trim($('#userid').val());
	var ownerName = $.trim($('#ownerName').val());
	var doe = $.trim($('#doe').val());
	var Gender = $.trim($('#Gender').val());	
	var mobile_number = $.trim($('#mobile_number').val());
	var role = $.trim($('#role').val());
	var Street_address = $.trim($('#Street_address').val());
	var area = $.trim($('#area').val());
	var city = $.trim($('#city').val());
	var District = $.trim($('#District').val());	
	var Country = $.trim($('#Country').val());
	var State = $.trim($('#State').val());	
	var Nationality = $.trim($('#Nationality').val());
	var Zip_code = $.trim($('#Zip_code').val());
	var whatsapp_number = $.trim($('#whatsapp_number').val());
	var email_id = $.trim($('#email_id').val());	
	var instagram_id = $.trim($('#instagram_id').val());
	var facebook_id = $.trim($('#facebook_id').val());
	var photo=$.trim($('#photo').val());
	var aadhar_card=$.trim($('#aadhar_card').val());
	var pan_card=$.trim($('#pan_card').val());

	var absPath = $('#photo').prop('src');

   	 alert(absPath);
	
     alert($('#photo').attr('src'));
	//alert("register Value::" + EmailID + "--" + Password);
	var arr = {
			id : userid,
			name : ownerName,
			phone_number : mobile_number,
			date_of_birth : doe,
			gender : Gender,
			role : role,
			street : Street_address,
			area : area,
			city : city,
			district : District,
			country : Country,
			state : State,
			nationality : Nationality,
			zip_code : Zip_code,
			photo:photo,
			whats_app_number : whatsapp_number,
			email_id : email_id,
			instragram_id : instagram_id,
			facebook_id : facebook_id,			
			photo : photo,
			aadhar_card : aadhar_card,
			pan_card : pan_card	
		};
	console.log(arr);
	$.ajax({
		url :'profile',
		type : 'PUT',
		data :JSON.stringify(arr),
		dataType : "text",
		contentType : 'application/json; charset=utf-8',
		success : function(response) {
			alert(response);
			var ERROR_MSG1 = "updated Sucessfully";
			var ERROR_MSG2 = "updated Failure";
		
			
			if(ERROR_MSG2==response)
				{
				 swal(
		                    {
		                        title : "updation Failure",
		                        type : 'error'
		                    },
		                    function() {
		                        window.location = "EditUser.html";
		                    });

				}
			else 
				{
				 swal(
		                    {
		                        title : "updated Sucessfully",
		                        type : 'success'
		                    },
		                    function() {
		                        window.location = "ViewUser.html";
		                    });
				
				}
		
		},
		error : function() {

		}
	});
		}
});
