package com.kavi.mecca.controller;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kavi.mecca.entity.Profile;
import com.kavi.mecca.entity.ProfileRepository;

@RestController
public class MeccaController {
	@Autowired
	ProfileRepository profileRepository;

	@PostMapping("/profile")
	public Profile createStudent(@RequestBody Profile profile) {
		String name = profile.getName();
		System.err.println(name);
		Profile savedprofile = profileRepository.save(profile);
		return savedprofile;
	}

	@GetMapping("/profile")
	List<Profile> testMethod() {
		List<Profile> profile = profileRepository.findAll();
		System.out.println(profile);
		return profile;
	}

	@GetMapping("/profile/{id}")
	Profile findById(@PathVariable("id") Long id) {
		// TODO Auto-generated method stub
		Optional<Profile> profile = profileRepository.findById(id);
		return profile.get();
	}
	@PutMapping("/profile")
	Profile updateProfile(@RequestBody Profile profile) {
		// TODO Auto-generated method stub
		Profile update_profile = profileRepository.save(profile);
		return update_profile ;
	}
	@DeleteMapping("/profile/{id}")
	String deleteProfile(@PathVariable("id") Long id) {
		// TODO Auto-generated method stub
		profileRepository.deleteById(id);
		return "deleted successfully" ;
	}
}
